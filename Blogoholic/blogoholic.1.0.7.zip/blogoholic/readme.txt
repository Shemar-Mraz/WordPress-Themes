=== blogoholic ===

Contributors: moralthemes
Tags: two-columns, three-columns, left-sidebar, right-sidebar, custom-background, custom-colors, custom-menu, custom-logo, editor-style, featured-images, footer-widgets, full-width-template, sticky-post, theme-options, threaded-comments, translation-ready, portfolio, blog
Requires PHP: 5.6
Requires at least: 5.0
Tested up to: 5.8
Stable tag: 1.0.7
License: GNU General Public License v2 or later
License URI: LICENSE

== Description ==

Blogoholic is super flexible and responsive. Its elegant design offers a user-friendly experience to the viewers. No matter the size and screen resolution, the theme can resize and looks perfect in all of them. It looks smooth and sophisticated, giving equal attention to your content being displayed. It is also cross-browser compatible and optimized for speed and performance.

== Installation ==

1. In your admin panel, go to Appearance > Themes and click the Add New button.
2. Click Upload Theme and Choose File, then select the theme's .zip file. Click Install Now.
3. Click Activate to use your new theme right away.

== How does the demo importer works? ==
Just install the recommended plugin i.e. Catch Themes Demo Import when the theme is activated and then go to Appearance->Moral Theme demo data.

= Does this theme support any plugins? =
Yes the theme is integrated to work with Catch Themes Demo Import.

== Copyright ==

Blogoholic WordPress Theme, Copyright 2020 Moral Themes
Blogoholic is distributed under the terms of the GNU GPL

This program is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 2 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
GNU General Public License for more details.

blogoholic bundles the following third-party resources:

Packery PACKAGED v2.1.1 Copyright 2016 Metafizzy
Licenses: https://packery.metafizzy.co/license.html
Source: http://packery.metafizzy.co

Font Awesome 4.7.0 by @davegandy
License: http://fontawesome.io/license (Font: SIL OFL 1.1, CSS: MIT License)
Source: http://fontawesome.io

== Images Copyright ==

Header image
License: CC0 1.0 Universal (CC0 1.0)
https://pxhere.com/en/photo/944564

Screenshot image:
License: CC0 1.0 Universal (CC0 1.0)
Source: https://pxhere.com/en/photo/948906

License: CC0 1.0 Universal (CC0 1.0)
Source: https://pxhere.com/en/photo/176539

License: CC0 1.0 Universal (CC0 1.0)
Source: https://pxhere.com/en/photo/54136

License: CC0 1.0 Universal (CC0 1.0)
Source: https://pxhere.com/en/photo/1597911

License: CC0 1.0 Universal (CC0 1.0)
Source: https://pxhere.com/en/photo/654371


== Changelog ==

= 1.0.7 - feb 4, 2022 =
* fixed pagination function issue

= 1.0.6 - october 19, 2021 =
* fixed minor theme bug

= 1.0.5 - october 1, 2021 =
* compressed images
* minor update design

= 1.0.4 - august 20, 2020 =
* Added theme url

= 1.0.3 - august 20, 2020 =
* Replaced images form pxhere 
* updated screenshot

= 1.0.2 - august 17, 2020 =
* Fixed the bugs mentioned by code reviewer 
* added blocks and pattenrs css compatible with WordPress 5.5

= 1.0.1 - Jul 22, 2020 =
* Initial release

== Credits ==

* Based on Underscores https://underscores.me/, (C) 2012-2017 Automattic, Inc., [GPLv2 or later](https://www.gnu.org/licenses/gpl-2.0.html)

* normalize.css https://necolas.github.io/normalize.css/, (C) 2012-2016 Nicolas Gallagher and Jonathan Neal, [MIT](https://opensource.org/licenses/MIT)

* class-breadcrumb-trail.php https://github.com/justintadlock/breadcrumb-trail, (C) 2008-2017 Justin Tadlock, [ GNU GPL, version 2 or later]

* class-tgm-plugin-activation.php https://github.com/TGMPA/TGM-Plugin-Activation [GNU General Public License v2.0]

* blogoholic WordPress Theme incorporates code from Twentyseventeen WordPress Theme, Twenty Seventeen WordPress Theme, Copyright 2016 WordPress.org is distributed under the terms of the GNU GPL

* SVG Icons function https://github.com/WordPress/twentyseventeen (C) 2016 WordPress.org, [GNU GPL, version 2 or later ( http://www.gnu.org/licenses/old-licenses/gpl-2.0.html )